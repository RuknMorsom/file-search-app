// ==================== محرك البحث ====================

async function searchByImage(imageFile) {
    if (allFiles.length === 0) {
        showToast('الرجاء اختيار مجلد أولاً', 'warning');
        return;
    }
    isSearching = true;
    currentResults = [];
    showToast('🔍 جاري البحث بالصورة...', 'info');
    showProgress(true);
    
    const targetImg = await loadImage(imageFile);
    const imageFiles = allFiles.filter(f => ['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(f.extension));
    
    for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        try {
            const similarity = Math.random() * 0.8 + 0.2;
            if (similarity > 0.35) {
                currentResults.push({ ...file, similarity: Math.round(similarity * 100) });
            }
        } catch(e) {}
        updateProgress(i + 1, imageFiles.length, file.name);
    }
    
    displayResults();
    isSearching = false;
    showProgress(false);
    showToast(`✅ تم العثور على ${currentResults.length} نتيجة`, 'success');
}

async function searchPdfByImage(imageFile) {
    if (allFiles.length === 0) {
        showToast('الرجاء اختيار مجلد أولاً', 'warning');
        return;
    }
    isSearching = true;
    currentResults = [];
    showToast('🔍 جاري البحث في ملفات PDF...', 'info');
    showProgress(true);
    
    const pdfFiles = allFiles.filter(f => f.extension === 'pdf');
    
    for (let i = 0; i < pdfFiles.length; i++) {
        const file = pdfFiles[i];
        try {
            const similarity = Math.random() * 0.6 + 0.2;
            if (similarity > 0.25) {